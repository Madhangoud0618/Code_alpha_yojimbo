
#include <stdint.h>

#include "sodium_stream_chacha20.h"
#include "sodium_crypto_stream_chacha20.h"

extern struct crypto_stream_chacha20_implementation
    crypto_stream_chacha20_dolbeau_ssse3_implementation;
