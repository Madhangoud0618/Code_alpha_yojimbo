
#ifndef randombytes_sysrandom_H
#define randombytes_sysrandom_H

#include "sodium_export.h"
#include "sodium_randombytes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern struct randombytes_implementation randombytes_sysrandom_implementation;

#ifdef __cplusplus
}
#endif

#endif
